﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Training
{
    public static class DateTimeUtils
    {
        public static DateTime AddWeeks(this DateTime dateTime, int incrementWeeks)
        {
            return dateTime.AddDays(incrementWeeks * 7).GetDateTimeDayOfWeek(DayOfWeek.Monday).Date;
        }
        public static DateTime GetDateTimeDayOfWeek(this DateTime dateTime, DayOfWeek dayOfWeek)
        {
            while (dateTime.DayOfWeek != dayOfWeek)
            {
                dateTime = dateTime.DayOfWeek > dayOfWeek && dayOfWeek != DayOfWeek.Sunday ? dateTime.AddDays(-1) : dateTime.AddDays(+1);
            }

            return dateTime;
        }

        public static DayOfWeek? NextDayOfWeek(this DateTime dateTime, List<DayOfWeek> daysOfWeek)
        {
            IEnumerable<DayOfWeek> nextDaysOfWeek = (from day in daysOfWeek
                                                     where ((int)day + 6) % 7 > ((int)dateTime.DayOfWeek + 6) % 7
                                                     select day).OrderBy(d => ((int)d + 6) % 7);

            return nextDaysOfWeek.Count() == 0 ? null : (DayOfWeek?)nextDaysOfWeek.First();
        }
        public static DayOfWeek? NextDayOfWeek(this DateTime dateTime, DaysOfWeekType dayOfMonth)
        {
            return dateTime.NextDayOfWeek(GetDaysOfWeek(dayOfMonth));
        }

        public static List<DayOfWeek> GetDaysOfWeek(DaysOfWeekType daysOfWeekType)
        {
            List<DayOfWeek> daysOfWeek = new List<DayOfWeek>();

            if (daysOfWeekType.HasFlag(DaysOfWeekType.Monday) == true) { daysOfWeek.Add(DayOfWeek.Monday); }
            if (daysOfWeekType.HasFlag(DaysOfWeekType.Tuesday) == true) { daysOfWeek.Add(DayOfWeek.Tuesday); }
            if (daysOfWeekType.HasFlag(DaysOfWeekType.Wednesday) == true) { daysOfWeek.Add(DayOfWeek.Wednesday); }
            if (daysOfWeekType.HasFlag(DaysOfWeekType.Thursday) == true) { daysOfWeek.Add(DayOfWeek.Thursday); }
            if (daysOfWeekType.HasFlag(DaysOfWeekType.Friday) == true) { daysOfWeek.Add(DayOfWeek.Friday); }
            if (daysOfWeekType.HasFlag(DaysOfWeekType.Saturday) == true) { daysOfWeek.Add(DayOfWeek.Saturday); }
            if (daysOfWeekType.HasFlag(DaysOfWeekType.Sunday) == true) { daysOfWeek.Add(DayOfWeek.Sunday); }

            return daysOfWeek;
        }

        public static TimeSpan GetTime(this DateTime? dateTime) { return dateTime.HasValue == true ? dateTime.Value.TimeOfDay : new TimeSpan(); }

        public static List<TimeSpan> GetTimesGap(this TimeSpan startTime, TimeSpan endTime, int gap, DailyType dailyType)
        {
            List<TimeSpan> times = new List<TimeSpan>();

            int hours = 0;
            int minutes = 0;
            int seconds = 0;

            switch (dailyType)
            {
                case DailyType.Hour:
                    hours = gap;
                    break;
                case DailyType.Minute:
                    minutes = gap;
                    break;
                case DailyType.Second:
                    seconds = gap;
                    break;
            }

            TimeSpan time = startTime;

            do
            {
                times.Add(time);

                time = time.Add(new TimeSpan(hours, minutes, seconds));
            } while (time.CompareTo(endTime) <= 0);

            return times;
        }
    }
}
